export default function (state = [], action) {
    switch (action.type) {
        case 'GET_API_USER':
        console.log("in reducer")
            return action.payload;
            break;
    }
    return state;
}
