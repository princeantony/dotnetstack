import axios from 'axios'

export const selectUser = (user) => {
    console.log("You clicked on user: ", user.first);
    return {
        type: 'USER_SELECTED',
        payload: user
    }
};

export const getApiUser = () => {
    console.log("in action before api call")
    const apiUserRequest = axios.get('http://jsonplaceholder.typicode.com/users')
    return (dispatch) => {
        console.log("in action before result come")
        apiUserRequest.then(({data}) => {
             console.log("in action before reducer call")
            dispatch({type: 'GET_API_USER', payload: data})
        }
        );
        
    }
};  