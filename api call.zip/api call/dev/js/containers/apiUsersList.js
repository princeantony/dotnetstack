import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {getApiUser} from '../actions/index'

class ApiUserDetail extends Component {
    
    componentWillMount()
    {
        console.log("in will mount before action call")
        {this.props.getApiUser()}
        console.log("in will mount after action call")
    }
        componentDidMount()
    {
        console.log("in did mount call") 
        
    }
    render() {
       console.log("inside render",this.props)
        if (!this.props.apiUsers) {
            return (<div>Here api users will disply...</div>);
        }
        return (
            <table>
                {this.renderApiUser()}    
            </table>
        );
    }

        renderApiUser() {
            console.log("in render api")
        return this.props.apiUsers.map((apiUser) => {
            return (
                <tr key={apiUser.id}>
                    <td>{this.props.apiUser.name} </td>
                    <td>{this.props.apiUser.email} </td>
                </tr>
            );
        });
    }
}


// "state.activeUser" is set in reducers/index.js
function mapStateToProps(state) {
    return {
        apiUsers: state.apiUsers
    };
}
// Get actions and pass them as props to to UserList
//      > now UserList has this.props.selectUser
function matchDispatchToProps(dispatch){
    return bindActionCreators({getApiUser: getApiUser}, dispatch);
}

export default connect(mapStateToProps,matchDispatchToProps)(ApiUserDetail);
