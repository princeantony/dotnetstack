import React, { Component } from 'react';
import {HEADER_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import {renderTooltip} from './form-components/Tooltip';
import {renderHyperLink, renderIcon} from './form-components/Form';
import FormField from './form-components/FormField';

class Header extends Component {
    render() {
        return (
           <div className="header height-80px pad-t-10px brd-b-silver">
                <div className="col-md-4 logo-sec">
                    <div className="logo"></div>
                </div>
                <div className="col-md-4 main-hdr">
                <h3 className="text-center mar-t-23px bold font-size-16px clr-blue">
                    {HEADER_CONSTANT.HEADER_TEXT}
                </h3>
            </div>
                <div className="col-md-4 links-hdr">
                    <div className="header-links mar-t-23px mar-t-0px-md text-cntr-ms">
                        <ul className="txt-aln-r font-size-12px">
                            <li>
                                    {renderIcon("fa fa-lg fa-question-circle pad-r-5px ")}
                                    {renderTooltip('userGuideTooltip',HEADER_CONSTANT.HELP_TEXT,POSITION.BOTTOM,(renderHyperLink('lnkUserGuide', HEADER_CONSTANT.USER_GUIDE_TEXT, HEADER_CONSTANT.USER_GUIDE_URL,'')))}

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            );
                                }
}

export default Header
