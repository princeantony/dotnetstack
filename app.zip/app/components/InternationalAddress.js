import React, { PropTypes, Component } from 'react';
import FormField from './form-components/FormField';
import {BORROWER_CONSTANT, POSITION} from '../constants/ApplicationConstants';

class InternationalAddress extends Component{
    render(){
        const{ borrowerinformation }=this.props;
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        return(<div>
                <div className="row">
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"Address1"} type="text" displayText={BORROWER_CONSTANT.ADDRESS1}  displayValue={borrowerinformation.Addresses[0].StreetName} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"Address2"} type="text"  displayText={BORROWER_CONSTANT.ADDRESS2} displayValue={borrowerinformation.Addresses[0].StreetNumber} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressTypess+"Region"} type="text" displayText={BORROWER_CONSTANT.REGION_PROVINCE} displayValue={borrowerinformation.Addresses[0].Province} />
                </div>
                <div className="row">
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"City"} type="text" displayText={BORROWER_CONSTANT.CITY} displayValue={borrowerinformation.Addresses[0].City} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"Country"} type="select-single" displayText={BORROWER_CONSTANT.COUNTRY} displayValue={borrowerinformation.Countries} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"ZipCode"} type="text" displayText={BORROWER_CONSTANT.ZIP_POSTAL_CODE} displayValue={borrowerinformation.Addresses[0].ZipCode} />
                      </div>
                  <div className="row">
                       {(this.props.addressType=="businessInter")?(
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType +"Facilities" } type="select-single" displayText={BORROWER_CONSTANT.FACILITIES} displayValue={borrowerinformation.Facilities} />
                      ):(<FormField columnSize="4" orientation="horizontal" id="rdoisFacilityIntr" type="radio" displayText={BORROWER_CONSTANT.RESIDENCE} displayValue={((borrowerinformation.Addresses[0].CountryId=="223")?false:true)} RadioType="HomeAddress" />)}

                </div>
                          <div className="row">
                           <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"MonthlyRent"} type="text" displayText={BORROWER_CONSTANT.MONTHLY_RENT_MORTGAGE_PAYMENT}  displayValue={''} />
                           <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"Property"} type="text"  displayText={BORROWER_CONSTANT.PROPERTY_VALUE} displayValue={''} />
                           <FormField columnSize="4" orientation={vertical} id={this.props.addressTypess+"Comments"} type="text" displayText={BORROWER_CONSTANT.COMMENTS} displayValue={''} />
                                   </div>
                              </div>)}
}
InternationalAddress.propTypes = {
    borrowerinformation :PropTypes.array.isRequired
}
export default InternationalAddress;
