import React, { PropTypes, Component } from 'react';
import {PRODUCTREQUEST_CONSTANT, POSITION, LEGEND_CONSTANT} from '../constants/ApplicationConstants';
import SubHeader from '../components/form-components/SubHeader';
import {renderSubSection} from './form-components/Form';
import FormField from './form-components/FormField';

class ProductRequest extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        const { productrequestinformation } =this.props
        let horizontal=POSITION.HORIZONTAL;
        return(
          <div>
          <div className="mar-t-0px"><SubHeader size="h4" value={PRODUCTREQUEST_CONSTANT.PRODUCT_REQUEST_INFORMATION} /></div>
          <form method="post" action="" name="productRequestForm" id="productRequestForm" ref="productRequestForm">
              <fieldset className="brd-radius-3px">
                      <div className="col-lg-12 pad-0px mar-0px">
                        <div className="row mar-l-5px mar-r-5px brd brd-radius-10px pad-14px">
                            <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} cssClass="clr-red" />
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="drpLoanRequest" type="select-single" displayText={PRODUCTREQUEST_CONSTANT.TYPE_OF_LOAN_REQUEST} displayValue={productrequestinformation.LoanTypeList} isRequired />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="drpProductType" type="select-single" displayText={PRODUCTREQUEST_CONSTANT.PRODUCT_TYPE} displayValue={productrequestinformation.ProductTypeList} isRequired />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="rdoIsPreFunding" type="radio" displayText={PRODUCTREQUEST_CONSTANT.PRE_FUNDING} displayValue={productrequestinformation.IsPrefunding} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="txtAmountRequested" type="text" displayText={PRODUCTREQUEST_CONSTANT.AMOUNT_REQUESTED} displayValue={productrequestinformation.AmtRequested} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="txtTotalCreExpLimit" type="text" displayText={PRODUCTREQUEST_CONSTANT.TOTAL_CREDIT_EXPOSURE_LIMIT} displayValue={productrequestinformation.TotalCreditExposureLimit} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="txtTotalDebExpLimit" type="text" displayText={PRODUCTREQUEST_CONSTANT.TOTAL_DEBIT_EXPOSURE_LIMIT} displayValue={productrequestinformation.TotalDebitExposureLimit} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="drpUseOfFunds" type="select-single" displayText={PRODUCTREQUEST_CONSTANT.USE_OF_FUNDS_PURPOSE} displayValue={productrequestinformation.UseOfFundsList} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="rdoIsRefinancingExistingDebt" type="radio" displayText={PRODUCTREQUEST_CONSTANT.REFINANCING_EXISTING_DEBT} displayValue={productrequestinformation.IsRefinancingExistingDebit} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="txtAccountNumber" type="select-single" displayText={PRODUCTREQUEST_CONSTANT.ACCOUNT_NUMBER} displayValue={productrequestinformation.AccountNumber}/>
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="rdoIsSBA" type="radio" displayText={PRODUCTREQUEST_CONSTANT.SBA} displayValue={productrequestinformation.SBA} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="rdoIsPurposeFarmRel" type="radio" displayText={PRODUCTREQUEST_CONSTANT.IS_PURPOSE_FARM_RELATED} displayValue={productrequestinformation.IsPurposeFarmRelated} isRequired />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="rdoIsAnyRegOAssociated" type="radio" displayText={PRODUCTREQUEST_CONSTANT.IS_ANY_REG_O_INSIDERS_ASSOCIATED_WITH_THIS_REQUEST} displayValue={productrequestinformation.IsAnyRegOInsidersAssociated} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="txtPromoCode" type="text" displayText={PRODUCTREQUEST_CONSTANT.PROMO_CODE} displayValue={productrequestinformation.PromoCode} />
                            </div>
                            <div className="row">
                                <FormField columnSize="4" orientation={horizontal} id="txtCompanyMgmntHistory" type="textarea" rows="3" cols="6" displayText={PRODUCTREQUEST_CONSTANT.COMPANY_MANAGEMENT_HISTORY} displayValue={productrequestinformation.CompanyManagementHistory} />
                            </div>
                            <div className="row">
                                {renderSubSection((PRODUCTREQUEST_CONSTANT.BILL_PAYER_SELECTION),
                                (
                                  [
                                    <div className="row"><FormField columnSize="4" orientation={horizontal} id="chkBillPayer"  type="checkbox" displayText={PRODUCTREQUEST_CONSTANT.BILL_PAYER_SELECTION} displayValue={productrequestinformation.IsBillPayerRegistered} /></div>,
                                    ((productrequestinformation.IsBillPayerRegistered==true)?(
                                    <div className="row"><FormField columnSize="4" orientation={horizontal} id="drpDDAOrSAV" type="select-single" displayText={PRODUCTREQUEST_CONSTANT.DDA_SAV} displayValue={productrequestinformation.StateList} /></div>,
                                    <div className="row"><FormField columnSize="4" orientation={horizontal} id="txtRoutingNumber"  type="text" displayText={PRODUCTREQUEST_CONSTANT.ROUTING_NUMBER} displayValue={productrequestinformation.BillPayer.RoutingNumber} /></div>,
                                    <div className="row"><FormField columnSize="4" orientation={horizontal} id="txtAccountNumber"  type="text" displayText={PRODUCTREQUEST_CONSTANT.ACCOUNT_NUMBER} displayValue={productrequestinformation.BillPayer.AccountNumber} /></div>):(<div></div>))
                                    ]
                                )
                                )}
                            </div>
                            <div className="row">
                              <div className="col-lg-12 pad-t-0px">
                                <input type="button" className="btn btn-primary pull-right" value="Done"  onClick={this._onSubmit.bind(this)}/>
                                </div>
                              </div>
                          </div>
                        </div>
                  </fieldset>
            </form>
                 
            </div>
              );
                            }
    onFieldChange(){
    }
                           
    _onSubmit(e){
        e.preventDefault();
    }
}
ProductRequest.PropTypes={
    productrequestinformation:PropTypes.object.isRequired
}
    export default ProductRequest;
