﻿import React, { Component } from 'react';
import FormField from './form-components/FormField';

let searchResults =  [
  {
      LegalEntityId:1,
      "Name": "Aaron Smith",
      "TIN/SSN": "90-2107895",
      "Address": "5755 Mill Pond Court West Bloomfield, MI 48322",
      "City/State" :"Cincinnati/OHIO",
      "Zipcode":"45228"
  },{
      LegalEntityId:2,
      "Name": "Aaron Smith",
      "TIN/SSN": "90-2107895",
      "Address": "5755 Mill Pond Court West Bloomfield, MI 48322",
      "City/State" :"Cincinnati/OHIO",
      "Zipcode":"45228"
  },{
      LegalEntityId:3,
      "Name": "Aaron Smith",
      "TIN/SSN": "90-2107895",
      "Address": "5755 Mill Pond Court West Bloomfield, MI 48322",
      "City/State" :"Cincinnati/OHIO",
      "Zipcode":"45228"
  },{
      LegalEntityId:4,
      "Name": "Aaron Smith",
      "TIN/SSN": "90-2107895",
      "Address": "5755 Mill Pond Court West Bloomfield, MI 48322",
      "City/State" :"Cincinnati/OHIO",
      "Zipcode":"45228"
  },{
      LegalEntityId:5,
      "Name": "Aaron Smith",
      "TIN/SSN": "90-2107895",
      "Address": "5755 Mill Pond Court West Bloomfield, MI 48322",
      "City/State" :"Cincinnati/OHIO",
      "Zipcode":"45228"
  },{
      LegalEntityId:6,
      "Name": "Aaron Smith",
      "TIN/SSN": "90-2107895",
      "Address": "5755 Mill Pond Court West Bloomfield, MI 48322",
      "City/State" :"Cincinnati/OHIO",
      "Zipcode":"45228"
  }
];
   

let _onRowSelect= (row, isSelected) =>{
    console.log(row);
    console.log("selected: " + isSelected);
}

let _onSelectAll=(isSelected)=>{
    console.log("is select all: " + isSelected);
}

class SearchPage extends Component {
    
    render() {
        return(
               <div>
                <form method="post" action="" name="searchForm" id="searchForm" ref="searchForm" >
                    <FormField id="grdSearch" type="grid" displayValue={searchResults} hover={true} selectType="radio" errorMessage={["You must correct the following error(s) before proceeding: Your search returned no results.", <br />, "Please select different criteria and perform the search again or  ", <a className="link" href="#">Add New Customer</a>, "."]} onRowSelect={this._onRowSelect} />
                        <div className="pad-r-40px pad-t-0px pad-b-0px pull-right">
                                          <div className="pull-left mar-r-10px ">
                                              <input type="button" className="btn btn-primary"  value="Add Borrower" />
                                              </div>
                                          <div className="pull-left mar-r-m-37px">
                                            <input type="button" className="btn btn-primary" value="Continue" />
                                           </div>
                         </div>
                </form>
               </div>
              );
    }
}

export default SearchPage;