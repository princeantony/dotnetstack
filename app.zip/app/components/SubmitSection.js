/*eslint-disable import/default */
import React, { Component, PropTypes } from 'react'
import ReactDOM from 'react-dom';
import ConfirmationPage from './ConfirmationPage';
import API from '../utils/WebAPI';

class SubmitSection extends Component {
    _onSubmit(){
        let confirmationDetails = API.submitLoanApplition(this.props.loanapplication);
        if(confirmationDetails!=null && confirmationDetails!='' && confirmationDetails!=undefined)
        {
            ReactDOM.render(<ConfirmationPage  confirmationDetails={confirmationDetails} />, document.getElementById('app'));
        }
    }
    render() {
        const { loanapplication } =this.props
        return(
                                    
            <div className="col-lg-12 mar-t-15px mar-b-15px pull-right">
            <div className="row">  
                                          <div className="pull-right pad-r-20px">
                                              <input type="button" className="btn btn-primary" value="Cancel" />
                                              </div>
                                          <div className="pull-right pad-r-20px">
                                            <input type="button" className="btn btn-primary" onClick={this._onSubmit.bind(this)} value="Submit/Print" />
                                           </div>
                                      </div>
            </div>
              );

    }
}

SubmitSection.PropTypes={
    loanapplication:PropTypes.object.isRequired
}
export default SubmitSection;
