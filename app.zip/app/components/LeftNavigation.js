/*eslint-disable import/default */
import React, { PropTypes, Component } from 'react';
import AppConstants from '../constants/ApplicationConstants';
import {renderSpan} from './form-components/Form';
import {Link} from 'react-router';

class LeftNavigation extends Component {
    constructor(props,context) {
        super(props,context);
        this.state={
            isBorrowerCollapsed:false,
            isProductCollapsed: true
        }
    }

    onProductClick() {
        let [...isProductCollapsed] = this.state.isProductCollapsed;
        isProductCollapsed = !this.state.isProductCollapsed;
        this.setState({isProductCollapsed: isProductCollapsed});
    }
    render() {
        const{ leftnavigationinformation }=this.props
        return(
          <div className="pad-t-10px">
       <div className="brd-l-whisper pad-t-5px left-div">
         <div id="borrowerSection" className="brd-b-dashed pad-b-10px pad-t-10px">
            <Link className="pad-l-14px" to="/LoanApp/LoanApplication/Load">{renderSpan('pad-l-5px bold label-color','','Borrower')}</Link>

         </div>
      <div className="brd-b-dashed pad-t-10px pad-b-10px">
          <span className={this.state.isProductCollapsed? 'fa fa-plus-square-o pad-l-5px cursor-pointer':'fa fa-minus-square-o pad-l-5px cursor-pointer'}
            onClick={this.onProductClick.bind(this)}></span>
              <span className="pad-l-5px bold label-color cursor-pointer" onClick={this.onProductClick.bind(this)}>Products</span>

            {!this.state.isProductCollapsed ?
              <div className="mar-l-20px">
                  <div className="pad-t-10px pad-b-10px">
                   <Link to="/LoanApp/LoanApplication/productRequest">{renderSpan('disabled','','Product Request '+leftnavigationinformation)}</Link>
                 </div><div className="pad-t-10px pad-b-10px">{renderSpan('disabled','ProductsAddNew','Add New Products')}</div>
             </div>: ''}
          </div>
        </div>
      </div>
       )
    }
        }

        LeftNavigation.propTypes = {
            leftnavigationinformation:PropTypes.number.isRequired

        }

export default LeftNavigation;
