﻿import React, { PropTypes, Component } from 'react';
import FormField from './form-components/FormField';
import {APPLICATIONSUMMARY_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import SubHeader from './form-components/SubHeader';

class ApplicationSummary extends Component {

    render() {
        const{ applicationsummary }=this.props
        let vertical=POSITION.VERTICAL;
        return(
          <div>
            <div className="mar-t-15px pad-l-10px-ms">
                        <SubHeader size="h4" value={APPLICATIONSUMMARY_CONSTANT.APPLICATION_SUMMARY}/>
                    </div>
          <div className="col-lg-12 brd brd-radius-10px mar-l-10px-ms mar-r-10px-ms bg-grey">
            <div className="pad-0px mar-0px">

            {(applicationsummary.SecurityRole=="Retail Manager")?
            (
               <fieldset className="brd-radius-3px pad-t-15px pad-b-15px">
                  <div className="col-lg-12 pad-l-0px pad-r-0px">
                  <div className="row">
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NAME} displayValue={applicationsummary.EmployeeName} />
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NUMBER} displayValue={applicationsummary.EmployeeNumber} />
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REGION} displayValue={applicationsummary.Affiliate} />
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.COST_CENTER_NUMBER} displayValue={applicationsummary.CostCenterNumber} />
                  </div>
                 </div>
                  <div className="col-lg-12 pad-l-0px pad-r-0px">
                  <div className="row">
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.FINANCIAL_CENTER_NAME_FC} displayValue={applicationsummary.FinancialCenter + ' (' + applicationsummary.FcNumber + ')'} />
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.APPLICATION_ID} displayValue={applicationsummary.ApplicationID} />
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REFERRED_BY_EMPLOYEE_ID} displayValue={applicationsummary.ReferredByEmployeeID} />
                    <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.RECIPIENT_OF_EMAIL_COMMUNICATION} displayValue={applicationsummary.RecipientEmailCommunication} />
                  </div>
                  </div>
              </fieldset>
            ):(
              <fieldset className="brd-radius-3px pad-t-15px pad-b-15px">
                 <div className="col-lg-12 pad-l-0px pad-r-0px">
                 <div className="row">
                   <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NAME} displayValue={applicationsummary.EmployeeName} />
                   <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NUMBER} displayValue={applicationsummary.EmployeeNumber} />
                   <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.Region} displayValue={applicationsummary.Affiliate} />
                   <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.FINANCIAL_CENTER_NAME_BB_PB_OFFICER} displayValue={applicationsummary.FinancialCenter + ' (' + applicationsummary.BbPbOfficerNumber + ')'} />
                 </div>
                </div>
                 <div className="col-lg-12 pad-l-0px pad-r-0px">
                 <div className="row">
                 <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.APPLICATION_ID} displayValue={applicationsummary.ApplicationID} />
                 <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REFERRED_BY_EMPLOYEE_ID} displayValue={applicationsummary.ReferredByEmployeeID} />
                 <FormField columnSize="3" orientation={vertical} type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.RECIPIENT_OF_EMAIL_COMMUNICATION} displayValue={applicationsummary.RecipientEmailCommunication} />
                 </div>
                 </div>
             </fieldset>
            )}
            </div>
          </div>
</div>
      );
            }
}

ApplicationSummary.propTypes = {
    applicationsummary:PropTypes.object.isRequired
}

export default ApplicationSummary;
