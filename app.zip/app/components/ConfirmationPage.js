﻿import React, { Component, PropTypes } from 'react';
import {renderSubSection} from './form-components/Form';
import {CONFIRMATION_PAGE_CONSTANT, POSITION, URL_CONSTANT} from '../constants/ApplicationConstants';
import Header from './Header';
import Footer from './Footer';
import FormField from './form-components/FormField';

class ConfirmationPage extends Component {
    render() {
        let horizontal=POSITION.HORIZONTAL;
        let {confirmationDetails} =this.props;
        return(
               <div>
                <Header/>
                  <div className="min-height">
                        {renderSubSection((CONFIRMATION_PAGE_CONSTANT.APP_SUBMITTED),
                        (
                            
                                [
                                    <div className="row">
                                                <FormField columnSize="8" orientation={horizontal} cssClass="clr-green bold font-size-12px mar-l-15px" type="label" value="The following requests have been submitted successfully" />
                                    </div>,
                                <div className="row"><FormField columnSize="2" orientation={horizontal} type="label-group" displayText={CONFIRMATION_PAGE_CONSTANT.APPLICATION_ID} displayValue={this.props.confirmationDetails[0]} /></div>,
                                <div className="row"><FormField columnSize="2" orientation={horizontal} type="label-group" displayText={CONFIRMATION_PAGE_CONSTANT.BORROWER_NAME} displayValue={this.props.confirmationDetails[3]} /></div>,
                                <div className="row"><FormField columnSize="2" orientation={horizontal} type="label-group" displayText={CONFIRMATION_PAGE_CONSTANT.PRODUCT_REQUESTS} displayValue={(this.props.confirmationDetails[1]) + " (" + (this.props.confirmationDetails[4]) + ")"} /></div>
                             ]
                       ))}

                            {renderSubSection((CONFIRMATION_PAGE_CONSTANT.NEXT_STEP),
                        (
                            
                                [
                                    <div className="row">
                                                <FormField columnSize="8" orientation={horizontal} cssClass="bold font-size-12px mar-l-15px" type="label" value="Print important documents" />
                                                <div className="mar-l-25px"><FormField columnSize="4" orientation={horizontal} targetType="_blank" cssClass="font-size-11px" id="lnkPDF" type="link" displayText="Please print the following application documents:" displayValue="Account Document (PDF)" href="#" /></div>
                                    </div>,
                                    <div className="row"><FormField columnSize="4" orientation={horizontal} targetType="_blank" cssClass="font-size-11px" id="lnkPDF" type="link" displayText={CONFIRMATION_PAGE_CONSTANT.CHECK_STATUS} displayValue="Workbench" href={URL_CONSTANT.WORKBENCH_URL} /></div>,
                                    <div className="row"><FormField columnSize="4" orientation={horizontal} targetType="_blank" cssClass="font-size-11px" id="lnkPDF" type="link" displayText={CONFIRMATION_PAGE_CONSTANT.CHECK_DECISION} displayValue="Decision Summary" href={'http://SDGRAMIHQCCWB04/DecisionFrameworkService/api/v1/DealSize?creditRequestId='+(this.props.confirmationDetails[0])+'&userId=E'+(this.props.confirmationDetails[5])} /></div>
                                                ]
                       ))}
                  </div>
                                                    <Footer/>
                                                 </div>
              );
                                                }
}
ConfirmationPage.PropTypes={
    confirmationDetails: PropTypes.object.isRequired
}


 export default ConfirmationPage;

