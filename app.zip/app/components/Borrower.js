import React, { PropTypes, Component } from 'react';
import {BORROWER_CONSTANT, POSITION, LEGEND_CONSTANT} from '../constants/ApplicationConstants';
import {renderTooltip} from './form-components/Tooltip';
import SubHeader from '../components/form-components/SubHeader';
import {renderSubSection, renderHyperLink, renderIcon} from './form-components/Form';
import FormField from './form-components/FormField';
import { browserHistory, Router } from 'react-router';
import DomesticAddress from './DomesticAddress';
import InternationalAddress from './InternationalAddress';



class Borrower extends Component {
    _onSubmit(){
        browserHistory.push('/LoanApp/LoanApplication/productRequest');
    }
    render() {
        const{ borrowerinformation,facilityinformation }=this.props
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        return(
<div>
<div className="pad-t-0px"><SubHeader size="h4" value={BORROWER_CONSTANT.BORROWER_BUSINESS_INFORMATION} /> </div>
<form method="post" action="" name="borrowerForm" id="borrowerForm" ref="borrowerForm" >
    <fieldset className="brd-radius-3px">
            <div className="col-lg-12 pad-0px mar-0px">
                <div className="row mar-l-5px mar-r-5px brd brd-radius-10px pad-14px">
                    <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} cssClass="clr-red" />
                    <div className="pad-5px font-size-11px">

        {renderSubSection((BORROWER_CONSTANT.BASIC_BUSINESS_INFORMATION),
    (
      [
          <div className="row">
                                <FormField columnSize="3" orientation={vertical} type="label-group" displayText={BORROWER_CONSTANT.ENTITY_STRUCTURE} displayValue={borrowerinformation.EntityStructure.Desc} />
                                <FormField columnSize="3" orientation={vertical} type="label-group" displayText={BORROWER_CONSTANT.BUSINESS_NAME} displayValue={borrowerinformation.LegalName} />
                                <FormField columnSize="3" orientation={vertical} type="label-group" displayText={BORROWER_CONSTANT.SSN_ITIN_OR_EIN} displayValue={((borrowerinformation.EntityStructure.Desc=="Individual")?(borrowerinformation.SocialSecurityNumber):(borrowerinformation.TaxId))} />
                                <FormField columnSize="3" orientation={vertical} type="label-group" displayText={BORROWER_CONSTANT.DATE_BUSINESS_STARTED} displayValue={borrowerinformation.YearBusinessStarted} />
                              </div>
                                ]
                       )
                     )}
                                    
                                    {(borrowerinformation.EntityStructure.StructureCode!="I" || borrowerinformation.EntityStructure.StructureCode==null) ?(renderSubSection((BORROWER_CONSTANT.BUSINESS_ADDRESS),
                     (
                       [
                         <div>
                          <div className="row">
                            <FormField columnSize="4" orientation="horizontal" id="rdoisBusinessDomestic" type="radio" displayText={BORROWER_CONSTANT.ADDRESS_TYPE} displayValue={((borrowerinformation.Addresses[0].CountryId!="223")?false:true)} RadioType="Address" />
                          </div>
                            {(borrowerinformation.Addresses[0].CountryId!="223") ?(<InternationalAddress addressType="businessInter" borrowerinformation={borrowerinformation} />):(<DomesticAddress addressType="businessDom" borrowerinformation={borrowerinformation}/>)}
                        </div>
                            ]
                     )
                     )):(
                                    [renderSubSection((BORROWER_CONSTANT.BUSINESS_ADDRESS),
                 (
                   [
                     <div>
                      <div className="row">
                        <FormField columnSize="4" orientation="horizontal" id="rdoisBusinessDomestic" type="radio" displayText={BORROWER_CONSTANT.ADDRESS_TYPE} displayValue={((borrowerinformation.Addresses[0].CountryId!="223")?false:true)} RadioType="Address" />
                      </div>
                        {(borrowerinformation.Addresses[0].CountryId!="223") ?(<InternationalAddress addressType="businessInter" borrowerinformation={borrowerinformation} />):(<DomesticAddress addressType="businessDom" borrowerinformation={borrowerinformation} />)}
                    </div>
                        ]
                 )
                 ),renderSubSection((BORROWER_CONSTANT.HOME_ADDRESS),
                 (
                   [
                         <div>
                          <div className="row">
                            <FormField columnSize="4" orientation="horizontal" id="rdoisHomeDomestic" type="radio" displayText={BORROWER_CONSTANT.ADDRESS_TYPE} displayValue={((borrowerinformation.Addresses[0].CountryId!="223")?false:true)} RadioType="Address" />
                          </div>
                            {(borrowerinformation.Addresses[0].CountryId!="223") ?(<InternationalAddress addressType="homeInter" borrowerinformation={borrowerinformation} />):(<DomesticAddress addressType="homeDom" borrowerinformation={borrowerinformation} />)}
                        </div>
                            ]
                 )
                 )])}
                

   

    {renderSubSection((BORROWER_CONSTANT.PHONE_NUMBERS),
        (
        [
          <FormField columnSize="4" orientation={vertical} id="businessPhoneNumber"  type="text" displayText={BORROWER_CONSTANT.BUSINESS} displayValue={borrowerinformation.WorkPhone} />,
          <FormField columnSize="4" orientation={vertical} id="homePhoneNumber" type="text" displayText={BORROWER_CONSTANT.HOME} displayValue={borrowerinformation.HomePhone}  />,
          <FormField columnSize="4" orientation={vertical} id="otherPhoneNumber"  type="text" displayText={BORROWER_CONSTANT.OTHER}  displayValue={borrowerinformation.OtherPhone} />,
          ]
     )
     )}

              {renderSubSection((BORROWER_CONSTANT.OTHER_DETAILS),
    (
      [
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="presentMagmntSince" dateGlobalizeFormat="MM/DD/YYYY" displayValue={(new Date().toISOString())} type="date" displayText={BORROWER_CONSTANT.PRESENT_MANAGEMENT_SINCE} /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="totalNumberOfEmployees" type="text" displayText={BORROWER_CONSTANT.TOTAL_NUMBER_OF_EMPLOYEES} displayValue={borrowerinformation.TotalNumberOfEmployees} /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} type="label-group" displayText={BORROWER_CONSTANT.FORMATION_STATE} displayValue={borrowerinformation.FormationState} /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="rdoIsFTEmployee" type="radio" displayText={BORROWER_CONSTANT.ARE_YOU_A_FIFTH_THIRD_EMPLOYEE} displayValue={borrowerinformation.IsFTBEmployee} isRequied /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="grossAnnualRevenue" type="text" displayText={BORROWER_CONSTANT.GROSS_ANNUAL_REVENUE} displayValue={borrowerinformation.GrossRevenue} /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="businessEmailAddress" type="text" displayText={BORROWER_CONSTANT.BUSINESS_EMAIL_ADDRESS} displayValue={borrowerinformation.BusinessEmailAddress} /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="rdoIsUSCitizen" type="radio" displayText={BORROWER_CONSTANT.IS_BORROWER_US_CITIZEN} displayValue={borrowerinformation.IsUSCitizen} isRequied /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="rdoIsBorrowerMortgageLender" type="radio" displayText={BORROWER_CONSTANT.IS_BORROWER_A_MORTGAGE_LENDER} displayValue={borrowerinformation.IsMortgageLender} isRequied /></div>,
        <div className="row"><FormField columnSize="4" orientation={horizontal} id="isBorrowerOwnerCollateral" type="checkbox" displayText={BORROWER_CONSTANT.THE_BORROWER_IS_THE_OWNER_OF_THE_COLLATERAL} displayValue={(borrowerinformation.IsOwnerForCollateral===true)?true:false} isRequired /></div>,
        <div className="row">
        <FormField columnSize="4" orientation={horizontal}  id="naicsCode" type="text" displayText={BORROWER_CONSTANT.NAICS_CODE} displayValue={borrowerinformation.NaicsCode.Attribute} isRequired isMultiple={true} />
        <div className="pad-t-5px font-size-11px">{renderHyperLink('lnkNaicsCode','NAICS Code Lookup','#', 'pad-l-30px')}</div>
            </div>,
            <div className="row"><FormField columnSize="4" orientation={horizontal} id="naicsCodeDesc" type="label-group" displayText={BORROWER_CONSTANT.NAICS_CODE_DESCRIPTION} displayValue={borrowerinformation.NaicsCode.Description} /></div>,
        ]
   )
   )}



                    </div>
                          <div className="col-lg-12 pad-t-0px">
                                <input type="button" className="btn btn-primary pull-right" value="Done"  onClick={this._onSubmit.bind(this)}/>
                        </div>
              </div>
          </div>
  </fieldset>
  </form>
</div>

              );

                    }
   
}


Borrower.propTypes = {
    borrowerinformation:PropTypes.object.isRequired,
    facilityinformation:PropTypes.object.isRequired
}
    export default Borrower;
