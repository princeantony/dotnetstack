import React, { Component, PropTypes } from 'react';
import CustomLabel from './Label';

class TextArea extends Component
{
    /*onChange(event) {
      if (this.props.onFieldChange)
      {
        event.data =
        {
          field: this.props.name,
          value: event.target.value
        };
  
        this.props.onFieldChange(event);
      }
    }*/
    render() {
        if (this.props.displayReadOnly)
        {
            return this.renderReadOnlyField();
        }

        return ((this.props.orientation=='horizontal')?(
          <div>
          <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabel()}
            </div>
            </div>
            <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderTextArea()}
            </div>
          </div>
          </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
          <div className="form-group">
          {this.renderLabel()}
              <div className="col-sm-12 pad-0px mar-0px">
                  {this.renderTextArea()}
              </div>
          </div>
      </div>
    ));
          }
    renderLabel() {
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }
    renderTextArea() {
        return <textarea 
        ref={this.props.id}
        id={this.props.id}
        className='textarea'
        rows={this.props.rows}
        cols={this.props.cols}
        name={this.props.id}
        value={this.props.displayValue}
        defaultValue={this.props.defaultValue}
        onChange={this.onChange} />;
    }
    renderReadOnlyField() {
        const readOnlyField =
        (<span>
          <span className={this.props.fieldNameClass}>
    {this.props.displayText}
  </span>
  &nbsp;
  <strong>
    {this.props.displayValue}
  </strong>
</span>
);

        return readOnlyField;
    }
}

export default TextArea;
