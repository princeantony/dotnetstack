import React, { Component, PropTypes } from 'react';
import CustomLabel from './Label';

class Select extends Component
{
    /*onChange(event) {
      if (this.props.onFieldChange)
      {
        const itemValue = event.target.value;
        let itemText;
  
        this.props.displayValue.forEach(item => {
          if (item.value === itemValue)
          {
            itemText = item.text;
          }
        });
  
        event.data =
        {
          field: this.props.name,
          value: itemValue,
          text: itemText
        };this.props.onFieldChange(event);
      }
    }*/

    render() {
        if (this.props.displayReadOnly)
        {
            return this.renderReadOnlyField();
        }
        return (
          (this.props.orientation=='horizontal')?(
            <div>
            <div className="form-group">
              <div className={"col-sm-"+this.props.columnSize}>
                    {this.renderLabel()}
              </div>
              </div>
              <div className="form-group">
              <div className={"col-sm-"+this.props.columnSize}>
                    {((this.props.displayValue!=null && this.props.displayValue!='')?(this.renderSelect()):(this.renderEmptySelect()))}
          </div>
        </div>
        </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
            <div className="form-group">
            {this.renderLabel()}
                <div className="col-sm-12 pad-0px mar-0px">
                    {((this.props.displayValue!=null && this.props.displayValue!='')?(this.renderSelect()):(this.renderEmptySelect()))}
                </div>
            </div>
        </div>
      )

      );
                }
    renderLabel() {
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }
    renderSelect() {
        let selectedValue = null;
        if (this.props.displayValue)
        {
            selectedValue = this.props.displayValue;
        }

        return (
                <div className="width-145px">
                <select
        ref={this.props.id}
        className='form-control'
        onChange={this.onChange}
        value={selectedValue} >
          {this.renderSelectItems()}
       </select>
       </div>);
    }


    renderEmptySelect() {
        let selectedValue = null;
        if (this.props.displayValue)
        {
            selectedValue = this.props.displayValue;
        }

        return (
                <div className="width-145px">
                <select
        ref={this.props.id}
        className='form-control'
        onChange={this.onChange}
        value={selectedValue} >
          <option key="0" value="0">Please Select</option>
       </select>
       </div>);
    }



    renderSelectItems() {
        return(this.props.displayValue.map(function(item, index) {
            return (<option key={index} value={item.Key}>{item.Value}</option>)
            }));
            }


    renderReadOnlyField() {
        const data = this.renderReadOnlyValue();
        const readOnlyField =
        (<span>
          <span className={this.props.fieldNameClass}>
    {this.props.displayText}
  </span>
  &nbsp;
  <strong>
    {data}
  </strong>
</span>
);
        return readOnlyField;
    }

    renderReadOnlyValue() {
        const self = this;
        if (self.props.data)
        {
            const field = self.props.menuItems.filter((item, index) => item.value == self.props.data);
            if (field && field.length > 0)
            {
                return field[0].text;
            }
            else
            {
                return null;
            }
        }
    }

}

Select.PropTypes={
    displayValue:PropTypes.array.isRequired
}
export default Select;
