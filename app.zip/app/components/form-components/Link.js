import React, { Component, PropTypes } from 'react';
import CustomLabel from './Label';

class Link extends Component
{

    renderLabel(){
        return <CustomLabel value={this.props.displayText} cssClass={"bold" + this.props.cssClass } isRequired={this.props.isRequired} />;
    }

    renderHyperLink(){
        return (<a id={this.props.id}
    className="link"
        target={this.props.targetType}
    name={this.props.id}
    ref={this.props.id}
    href={this.props.href}>
    {this.props.displayValue}
    </a>);
    }

    render() {
        return ((this.props.orientation=='horizontal')?(
          <div>
          <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabel()}
            </div>
            </div>
            <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderHyperLink()}
            </div>
          </div>
          </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
          <div className="form-group">
          {this.renderLabel()}
              <div className="col-sm-12 pad-0px mar-0px mar-l-10px">
                  {this.renderHyperLink()}
              </div>
          </div>
      </div>
    ));
          }

}

Link.propTypes = {
    id:PropTypes.string.isRequired,
    href:PropTypes.string.isRequired,
    displayValue:PropTypes.string.isRequired
}
export default Link;
