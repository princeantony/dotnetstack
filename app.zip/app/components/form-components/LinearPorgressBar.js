﻿import React, {Component, PropTypes} from 'react';
import ProgressBar from 'react-bootstrap/lib/ProgressBar';

export default class LinearProgressBar extends Component{
    constructor(props) {
        super(props);
        this.state = {
            completed: this.props.min
        };
    }

    componentDidMount() {
        setTimeout(() => this.progress(5), this.props.delay);
    }

    componentWillUnmount() {
        ///clearTimeout(this.timer);
    }

    progress(completed) {
        if (completed > this.props.max) {
            this.setState({completed: this.props.max});
        } else {
            this.setState({completed});
            const diff = Math.random() * 10;
            setTimeout(() => this.progress(completed + diff), this.props.delay);
        }
    }

    render() {
        return (
          <ProgressBar active={this.props.isActive} bsClass={this.props.cssClass} bsStyle={this.props.customStyle} label={this.props.displayText} striped={this.props.isStriped} max={this.props.max} min={this.props.min} now={this.state.completed} />
    );
    }
}

LinearProgressBar.propTypes={
    min: PropTypes.number,
    now: PropTypes.number,
    max: PropTypes.number,
    label: PropTypes.node,
    striped: PropTypes.bool,
    active: PropTypes.bool,
    cssClass: PropTypes.string,
    delay:PropTypes.number.isRequired
}

ProgressBar.defaultProps = {
    min: 0,
    max: 100,
    active: false,
    striped: false
};