﻿import React, { Component, PropTypes } from 'react';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table'; 
import {validateArrayData} from '../../utils/Functions';
import FormField from './FormField';
import _ from 'lodash';


class Grid extends Component
{
   
    _generateColumnGrid(){
        let isValid = validateArrayData(this.props.displayValue);

        let _onRowSelect=(row, isSelected)=>{
            this.props.onRowSelect(row, isSelected);
            console.log(row);
            console.log("selected: " + isSelected)
        }

        let _onSelectAll=(isSelected)=>{
            console.log("is select all: " + isSelected);
        }

        let selectRowProp= ((this.props.selectType==='radio')?(
         {
             mode: "radio",
             clickToSelect: true,
             bgColor: "rgb(238, 193, 213)",
             onSelect: this.props.onRowSelect
         }):({
             mode: "checkbox",
             clickToSelect: true,
             bgColor: "rgb(238, 193, 213)",
             onSelect: _onRowSelect,
             onSelectAll: _onSelectAll
         }));
        return((isValid)?
                (<div>
                    <label><span className="bold">Search Results: {this.props.displayValue.length}</span> Records Found</label>
                 <BootstrapTable  data={this.props.displayValue} hover={this.props.hover} condensed={true} selectRow={selectRowProp} pagination={true}>
                 <TableHeaderColumn isKey={true} dataField="LegalEntityId" className="bold thead display-none" columnClassName="info display-none">LegalEntity ID</TableHeaderColumn>
                        <TableHeaderColumn dataField="Name" className="bold thead width-15-per" columnClassName="info width-15-per">Name</TableHeaderColumn>
                        <TableHeaderColumn dataField="TIN/SSN" className="bold thead width-15-per" columnClassName="info width-15-per">TIN/SSN</TableHeaderColumn>
                        <TableHeaderColumn dataField="Address" className="bold thead width-40-per" columnClassName="info width-40-per">Address</TableHeaderColumn>
                        <TableHeaderColumn dataField="City/State" className="bold thead width-15-per" columnClassName="info width-15-per">City/State</TableHeaderColumn>
                        <TableHeaderColumn dataField="Zipcode" className="bold thead width-15-per" columnClassName="info width-15-per">Zipcode</TableHeaderColumn>
                </BootstrapTable>
                    {_.map(this.props.displayValue, 
                       'Address'
                    )}
               </div>):(<FormField id="lblError" type="message" cssClass="text-danger txt-aln-c" displayText={this.props.errorMessage} />));
                }

    render() {
        return (
            <div>
                {this._generateColumnGrid()}
            </div>
    );
    }
}

Grid.propTypes = {
    id:PropTypes.string.isRequired,
    displayValue: PropTypes.array.isRequired,
    hover:PropTypes.bool,
    onRowSelect:PropTypes.func,
}
export default Grid;
