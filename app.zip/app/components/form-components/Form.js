﻿import React from 'react';

let renderHyperLink = (id,linkText,url, cssClass) => {
    return (<a id={id} className={'link  ' + cssClass} ref={id} href={url}>{linkText}</a>);
}

let renderIcon = (classIcon) => {
    return (<i className={classIcon + "label-color cursor-pointer"}  aria-hidden="true"></i>);
}

let renderSpan = (cssClass,id,text) => {
    return(<span id={id}  className={cssClass}>{text}</span>);
}

let renderSubSection = (subHeaderValue,childComponent) => {
    return(
             <div>
             <h6 className="label-color bold">
                 {subHeaderValue}
             </h6>
             <div className="col-lg-12 pad-t-15px pad-b-15px pad-r-0px pad-l-0px brd brd-radius-10px mar-b-15px">
                   {childComponent}
              </div>
             </div>
        );
}




export {
renderHyperLink, renderIcon, renderSpan, renderSubSection
};