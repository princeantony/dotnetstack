import React, { PropTypes, Component } from 'react';
import classSet from 'classnames';

import CustomLabel from './Label';
import Image from './Image';
import Link from './Link';
import TextField from './TextField';
import TextArea from './TextArea';
import RadioGroup from './RadioGroup';
import CheckboxGroup from './CheckboxGroup';
import Select from './Select';
import DatePicker from './DatePicker';
import LabelGroup from './LabelGroup';

class DynamicField extends Component {
  render() {
    ///const classes = { 'form-group': true };
    ///let colClass = 'col-xs-12';

    /*if (this.props.width)
    {
      colClass = `col-xs-${this.props.width}`;
    }

    classes[colClass] = true;
    const className = classSet(this.props.className, classes);*/
    const className ="";
    if (this.props.displayReadOnly)
    {
      return <span>{this.renderField()}</span>;
    }
    ///className={className}
    return <div >
            {this.renderField()}
            {this.renderHelp()}
           </div>;
  }

renderField()
{
      let statusClass;
      if (this.props.validation)
      {
        if (this.props.errors && this.props.errors.length > 0)
          {
          statusClass = 'has-error';
        }
        else if (this.props.data)
        {
          statusClass = 'has-success';
        }
      }

      switch (this.props.type)
      {
        case 'image':
        {
          return <Image {...this.props} />;
        }
        case 'link':
        {
          return <Link {...this.props} />;
        }
        case 'label':
        {
          return <CustomLabel {...this.props} />;
        }
        case 'label-group':
        {
          return <LabelGroup {...this.props} />;
        }
        case 'radio' :
        {
          return <RadioGroup {...this.props} onFieldChange={this.props.onFieldChange} />;///statusClass={statusClass}
        }
        case 'checkbox' :
        {
          return <CheckboxGroup {...this.props} />;///statusClass={statusClass}
        }
        case 'text' :
        {
          return <TextField {...this.props} onFieldChange={this.props.onFieldChange} />;///statusClass={statusClass}
        }
        case 'textarea' :
        {
          return <TextArea {...this.props} onFieldChange={this.props.onFieldChange} />;///statusClass={statusClass}
        }
        case 'select-single':
        {
          return <Select {...this.props} onFieldChange={this.props.onFieldChange} />;
        }
        case 'date':
        {
          return <DatePicker {...this.props} onFieldChange={this.props.onFieldChange} />;
        }

      }
}
  renderHelp() {
    if (this.props.help || (this.props.validation && this.props.validation.message))
    {
      if (this.props.validation && this.props.errors && this.props.errors.length > 0)
      {
        const message = (this.props.validation ? (this.props.validation.message || this.props.help) : this.props.help);

        return this.renderMessage('text-danger', 'fa fa-warning', message );
      }
      else if (this.props.help)
      {
        return this.renderMessage('text-info', 'fa fa-info-circle', this.props.help);
      }
    }
  }
  renderMessage(className, classIcon, message) {
    return <div className={className}>
            <small><i className={classIcon}></i>&nbsp;{message}</small>
           </div>;
  }
}

export default DynamicField;
