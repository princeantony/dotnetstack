import React, { Component, PropTypes } from 'react';
import CustomLabel from './Label';

class LabelGroup extends Component
{

    renderLabel(){
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }

    renderLabelValue(){
        return <CustomLabel  value={this.props.displayValue} />;
    }

    render() {
        return ((this.props.orientation=='horizontal')?(
          <div>
          <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabel()}
            </div>
            </div>
            <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabelValue()}
            </div>
          </div>
          </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
          <div className="form-group">
          {this.renderLabel()}
              <div className="col-sm-12 pad-0px mar-0px">
                  {this.renderLabelValue()}
              </div>
          </div>
      </div>
    ));
          }

}

LabelGroup.propTypes = {
}

export default LabelGroup;
