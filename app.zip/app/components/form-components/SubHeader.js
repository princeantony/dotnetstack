﻿import React, { PropTypes, Component } from 'react';

class SubHeader extends Component {
    render() {
        let cssClass="pad-l-5px pad-r-5px bold font-size-14px label-color";
        switch(this.props.size)
        {
            case 'h4': return <h4 className={cssClass}>{this.props.value}</h4>;
        }
    }
}

SubHeader.propTypes = {
    value:PropTypes.string.isRequired,
    size:PropTypes.string.isRequired
}
export default SubHeader;
