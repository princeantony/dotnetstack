﻿import React, { Component, PropTypes } from 'react';

class Messages extends Component
{
    render() {
        return (
            <div id={this.props.id} ref={this.props.id}
            className={this.props.cssClass}>{this.props.displayText}</div>
               );
            }
}
Messages.propTypes = {
    id:PropTypes.string.isRequired,
}
export default Messages;
