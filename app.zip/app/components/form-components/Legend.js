﻿import React, {Component, PropTypes} from 'react';

class Legend extends Component {
    render() {
        return (
            <div className="txt-aln-r col-lg-12">
                <label className={this.props.cssClass}>{this.props.displayText}</label>
            </div>
        );
    }
}

Legend.propTypes={
    cssClass: PropTypes.string,
    displayText:PropTypes.string.isRequired
}

export default Legend;