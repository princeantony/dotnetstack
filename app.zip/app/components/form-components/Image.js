import React, { Component, PropTypes } from 'react';

class Image extends Component
{
    render() {
        return (
          <img id={this.props.id}
    className={this.props.cssClass}
    name={this.props.id}
    ref={this.props.id}
    src={this.props.src}
    alt={this.props.id} />
);
    }
}
Image.propTypes = {
    id:PropTypes.string.isRequired,
    src:PropTypes.string.isRequired
}
export default Image;
