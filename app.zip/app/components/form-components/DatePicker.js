import React, { Component, PropTypes } from 'react';
import CustomLabel from './Label';
import DatePicker from 'react-bootstrap-date-picker';
import moment from 'moment';


class StandardDateField extends Component
{
    onChange(data) {
        const event = [];
        const date = moment(data).format(this.props.dateSaveFormat);
        const value = date == 'Invalid date' ? '' : date;

        if (this.props.onFieldChange)
        {
            event.data =
            {
                field: this.props.id,
                value
            };

            this.props.onFieldChange(event);
        }
    }
    render() {
        if (this.props.displayReadOnly)
        {
            return this.renderReadOnlyField();
        }

        return ((this.props.orientation=='horizontal')?(
          <div>
          <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabel()}
            </div>
            </div>
            <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderDate()}
            </div>
          </div>
          </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
            <div className="form-group">
            {this.renderLabel()}
                <div className="col-sm-12 pad-0px mar-0px">
                 {this.renderDate()}
                </div>
            </div>
        </div>
      ));

            }
    renderLabel() {
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }

    renderDate() {
        var dateValue = this.props.displayValue == undefined || this.props.displayValue == '' ? '' : (new Date(this.props.displayValue).toISOString());
        const enableTime = this.props.enableTime == undefined ? false : this.props.enableTime;
        return (
        <div className="width-145px">
        <DatePicker
        ref={this.props.id}
        id={this.props.id}
        name={this.props.id}
        value={dateValue}
        format={this.props.dateGlobalizeFormat}
        editFormat={this.props.dateGlobalizeFormat}
        defaultValue={dateValue}
        onChange={this.onChange} />
         </div>);
    }



    renderReadOnlyField() {
        const readOnlyField =
        (<span>
          <span className={this.props.fieldNameClass}>
            {this.props.displayText}
          </span>
          &nbsp;
          <strong>
            {this.props.displayValue}
          </strong>
        </span>
);

        return readOnlyField;
    }
}

export default StandardDateField;
