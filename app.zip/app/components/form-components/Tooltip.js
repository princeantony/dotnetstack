﻿import React from 'react';
import OverlayTrigger from 'react-bootstrap/lib/OverlayTrigger';
import Tooltip from 'react-bootstrap/lib/Tooltip';

export  function renderTooltip(tooltipId,tooltipText,tooltipDirection,control){
    let tooltip=  (<Tooltip id={tooltipId}><strong>{tooltipText}</strong></Tooltip>);
return(<OverlayTrigger placement={tooltipDirection} overlay={tooltip}>{control}</OverlayTrigger>);
}
