import React, { Component, PropTypes } from 'react';
import CustomLabel from './Label';

class Radiogroup extends Component
{

    renderLabel(){
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }

    renderRadiogroup(){
        return((this.props.RadioType=="HomeAddress")?(<div className="form-group">
                            <div className="mar-t-m-2px float-l mar-r-6px">
                                <input type="radio" name={this.props.id} id={(this.props.id+"Month")} checked={((this.props.displayValue==true)?(true):(false))} />
                                            </div>
                                            <div className="float-l mar-r-6px">
                                                <label>
                                            Monthly Rent/Mortgage Payment
                                                </label>
                                            </div>
                                            <div className="mar-t-m-2px float-l mar-r-6px">
                                                <input type="radio" name={this.props.id} id={(this.props.id+"Property")} checked={((this.props.displayValue==false)?(true):(false))} />
                                            </div>
                                            <div className="float-l mar-r-6px">
                                                <label>
                                            Property Value
                                                </label>
												</div>
                                                <div className="mar-t-m-2px float-l mar-r-6px">
                                                <input type="radio" name={this.props.id} id={(this.props.id+"Comments")} checked={((this.props.displayValue==false)?(true):(false))} />
                                            </div>
                                            <div className="float-l mar-r-6px">
                                                <label>
                                            Comments
                                                </label>
                                            </div>
    </div>):(<div className="form-group">
                            <div className="mar-t-m-2px float-l mar-r-6px">
                     <input type="radio" name={this.props.id} id={(this.props.id+"Yes")} checked={((this.props.displayValue==true)?(true):(false))} />
           </div>
           <div className="float-l mar-r-6px">
               <label>
           {(this.props.RadioType=="Address")?('Domestic'):('Yes')}
               </label>
           </div>
           <div className="mar-t-m-2px float-l mar-r-6px">
               <input type="radio" name={this.props.id} id={(this.props.id+"No")} checked={((this.props.displayValue==false)?(true):(false))} />
           </div>
           <div className="float-l mar-r-6px">
               <label>
           {(this.props.RadioType=="Address")?('International'):('No')}
               </label>
           </div>
        </div>));
               }
    render() {
        return ((this.props.orientation=='horizontal')?(
          <div>
          <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabel()}
            </div>
            </div>
            <div className="form-group">
            <div className={"col-sm-8"}>
                  {this.renderRadiogroup()}
            </div>
          </div>
          </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
          <div className="form-group">
          {this.renderLabel()}
              <div className="col-sm-12 pad-0px mar-0px">
                  {this.renderRadiogroup()}
              </div>
          </div>
      </div>
    ));
          }

}

Radiogroup.propTypes = {
}

export default Radiogroup;
