import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import CustomLabel from './Label';

class TextField extends Component
{
   /* onBlur(event) {
      if (this.props.onFieldBlur)
     {
        event.data =
        {
          field: this.props.id,
          value: event.target.value
        };
  
        this.props.onFieldBlur(event);
      }
    }
    onChange(event) {
      if (this.props.onFieldChange)
      {
        event.data =
        {
          field: this.props.id,
          value: event.target.value
        };
        this.props.onFieldChange(event);
      }
    }*/
    render() {
        if (this.props.displayReadOnly)
        {
            return this.renderReadOnlyField();
        }

        return ((this.props.orientation=='horizontal')?(
          <div>
          <div className="form-group">
            <div className={"col-sm-"+this.props.columnSize}>
                  {this.renderLabel()}
            </div>
            </div>
            <div className="form-group">
            <div className={(this.props.isMultiple)?("col-sm-"+this.props.columnSize/2):("col-sm-"+this.props.columnSize)}>
                  {this.renderInput()}
            </div>
          </div>
          </div>
      ):(
        <div className={"col-lg-"+this.props.columnSize}>
          <div className="form-group">
          {this.renderLabel()}
              <div className="col-sm-12 pad-0px mar-0px">
                  {this.renderInput()}
              </div>
          </div>
      </div>
    ));
          }
    renderLabel() {
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }
    renderInput() {
        return (
                <div className="width-145px">
                <input 
        ref={this.props.id}
        type="text"
        className='form-control'
        name={this.props.id}
        value={this.props.displayValue}
        onBlur = {this.onBlur}
        onChange={this.onChange} />
        </div>);
    }
    renderReadOnlyField() {
        const readOnlyField =
        (<span>
          <span className={this.props.fieldNameClass}>
    {this.props.displayText}
  </span>
  &nbsp;
  <strong>
    {this.props.displayValue}
  </strong>
</span>
);

        return readOnlyField;
    }
}

export default TextField;
