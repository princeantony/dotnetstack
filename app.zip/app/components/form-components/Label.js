import React, { Component, PropTypes } from 'react';

class CustomLabel extends Component
{
    render() {
        return  <div><label id={this.props.id} ref={this.props.id} className={this.props.cssClass}>{this.props.value}</label>{((this.props.isRequired==true)?(<span className="clr-red pad-l-5px bold font-size-11px">*</span>):(''))}</div>;
        }

        }
    CustomLabel.propTypes = {
        }

    export default CustomLabel;