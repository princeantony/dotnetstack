import React, { PropTypes, Component } from 'react';
import {BORROWER_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import FormField from './form-components/FormField';

class DomesticAddress extends Component{
    render(){
        const{ borrowerinformation }=this.props;
    let vertical=POSITION.VERTICAL;
    let horizontal=POSITION.HORIZONTAL;
    return(<div>
            <div className="row">
              <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"StreetAddress"} type="text" displayText={BORROWER_CONSTANT.STREET_ADDRESS}  displayValue={borrowerinformation.Addresses[0].StreetName} />
              <FormField columnSize="4" orientation={vertical} id={this.props.iaddressTypess+"City"} type="text" displayText={BORROWER_CONSTANT.CITY} displayValue={borrowerinformation.Addresses[0].City} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"State"} type="select-single" displayText={BORROWER_CONSTANT.STATE} displayValue={borrowerinformation.States} />
            </div>
            <div className="row">
              <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"ZipCode"} type="text" displayText={BORROWER_CONSTANT.ZIP_POSTAL_CODE} displayValue={borrowerinformation.Addresses[0].ZipCode} />
              <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"County"} type="text" displayText={BORROWER_CONSTANT.COUNTY} displayValue={borrowerinformation.Addresses[0].County} />
            </div>
            <div className="row">
                {(this.props.addressType=="businessDom")?(
                        <FormField columnSize="4" orientation={vertical} id={this.props.addressType +"Facilities" } type="select-single" displayText={BORROWER_CONSTANT.FACILITIES} displayValue={borrowerinformation.Facilities} />
                    ):(
                    <FormField columnSize="4" orientation="horizontal" id="rdoisFacilityDomestic" type="radio" displayText={BORROWER_CONSTANT.RESIDENCE} displayValue={((borrowerinformation.Addresses[0].CountryId=="223")?false:true)} RadioType="HomeAddress" />
                    )}
            </div>
            <div className="row">
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"MonthlyRent"} type="text" displayText={BORROWER_CONSTANT.MONTHLY_RENT_MORTGAGE_PAYMENT}  displayValue={''} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressType+"Property"} type="text"  displayText={BORROWER_CONSTANT.PROPERTY_VALUE} displayValue={''} />
                  <FormField columnSize="4" orientation={vertical} id={this.props.addressTypess+"Comments"} type="text" displayText={BORROWER_CONSTANT.COMMENTS} displayValue={''} />
                </div>
          </div>)
  }
}
                DomesticAddress.propTypes = {
                    borrowerinformation:PropTypes.object.isRequired
                }
export default DomesticAddress;
