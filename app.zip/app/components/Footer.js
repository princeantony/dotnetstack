﻿import React, { Component } from 'react';
import {FOOTER_CONSTANT} from '../constants/ApplicationConstants';

class Footer extends Component {
    
    render() {
        return(
                <div className="footer text-center brd-t-silver  pad-b-5px  mar-t-9px"><p className="mar-l-3px">&copy; {FOOTER_CONSTANT.FOOTER_TEXT}</p></div>
              ); 
    }
}

    export default Footer;