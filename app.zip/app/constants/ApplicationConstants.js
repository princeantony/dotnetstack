﻿export const HEADER_CONSTANT=
{
    FIFTH_THIRD_LOGO: '../public/assets/images/Logo.png',
    HEADER_TEXT: 'Small Business Loan Application',
    HELP_TEXT:'Help',
    USER_GUIDE_URL: '#',
    USER_GUIDE_TEXT:'User Guide'
};

export const APPLICATIONSUMMARY_CONSTANT=
{
    APPLICATION_SUMMARY: 'Application Summary',
    EMPLOYEE_NAME:'Employee Name',
    EMPLOYEE_NUMBER:'Employee Number',
    REGION:'Region',
    COST_CENTER_NUMBER:'Cost Center Number',
    FINANCIAL_CENTER_NAME_FC:'Financial Center Name (FC#)',
    APPLICATION_ID:'Application ID',
    RECIPIENT_OF_EMAIL_COMMUNICATION:'Recipient of Email Communication',
    FINANCIAL_CENTER_NAME_BB_PB_OFFICER:'Financial Center Name (BB/PB Officer#)',
    REFERRED_BY_EMPLOYEE_ID:'Referred by Employee ID'
};

export const BORROWER_CONSTANT=
{ 
    BORROWER_BUSINESS_INFORMATION:'Borrower Business Information',
    REFRESH_TEXT:'Refresh',
    BASIC_BUSINESS_INFORMATION:'Basic Business Information',
    ENTITY_STRUCTURE:'Entity Structure',
    BUSINESS_NAME:'Business Name',
    SSN_ITIN_OR_EIN:'SSN/ITIN or EIN',
    DATE_BUSINESS_STARTED:'Date Business Started',
    BUSINESS_ADDRESS:'Business Address',
    ADDRESS1:'Address 1',
    ADDRESS2:'Address 2',
    REGION_PROVINCE:'Region/Province(not required)',
    HOME_ADDRESS:'Home Address',
    ADDRESS_TYPE:'Address Type',
    STREET_ADDRESS:'Street Address',
    RESIDENCE:'Residence',
    APT_SUITE:'Apt/suite',
    CITY:'City',
    STATE:'State',
    ZIP_POSTAL_CODE:'Zip/Postal Code',
    COUNTY:'County',
    COUNTRY:'Country',
    FACILITIES:'Facilities',
    MONTHLY_RENT_MORTGAGE_PAYMENT:'Monthly Rent/Mortgage Payment',
    PROPERTY_VALUE:'Property Value',
    COMMENTS:'Comments',
    PHONE_NUMBERS:'Phone Numbers',
    BUSINESS:'Business',
    HOME:'Home',
    OTHER:'Other',
    OTHER_DETAILS:'Other Details',
    PRESENT_MANAGEMENT_SINCE:'Present Management Since',
    TOTAL_NUMBER_OF_EMPLOYEES:'Total Number of Employees',
    FORMATION_STATE:'Formation State',
    ARE_YOU_A_FIFTH_THIRD_EMPLOYEE :'Are you a Fifth Third employee ?',
    GROSS_ANNUAL_REVENUE:'Gross Annual Revenue',
    BUSINESS_EMAIL_ADDRESS:'Business Email Address',
    IS_BORROWER_US_CITIZEN:'Is Borrower US Citizen ?',
    IS_BORROWER_A_MORTGAGE_LENDER:'Is Borrower a Mortgage Lender ?',
    THE_BORROWER_IS_THE_OWNER_OF_THE_COLLATERAL:'The Borrower is the owner of the collateral ?',
    NAICS_CODE:'NAICS Code',
    NAICS_CODE_DESCRIPTION:'NAICS Code Description'
};

export const PRODUCTREQUEST_CONSTANT=
{
    PRODUCT_REQUEST_INFORMATION:'Product Request Information',
    TYPE_OF_LOAN_REQUEST:'Type of Loan Request',
    PRODUCT_TYPE:'Product type',
    PRE_FUNDING:'Pre-funding ?',
    AMOUNT_REQUESTED:'Amount Requested',
    TOTAL_CREDIT_EXPOSURE_LIMIT:'Total Credit Exposure Limit',
    TOTAL_DEBIT_EXPOSURE_LIMIT:'Total Debit Exposure Limit',
    USE_OF_FUNDS_PURPOSE:'Use of Funds (Purpose)',
    REFINANCING_EXISTING_DEBT:'Refinancing Existing Debt ?',
    SBA:'SBA ?',
    IS_PURPOSE_FARM_RELATED:'Is Purpose Farm-Related ?',
    IS_ANY_REG_O_INSIDERS_ASSOCIATED_WITH_THIS_REQUEST:'Is any Reg-O (insiders) associated with this request ?',
    PROMO_CODE:'Promo Code',
    TEXTAREA:'textarea',
    COMPANY_MANAGEMENT_HISTORY:'Company/Management History',
    BILL_PAYER_SELECTION:'Bill Payer Selection',
    DDA_SAV:'DDA #/SAV',
    ROUTING_NUMBER:'Routing Number',
    ACCOUNT_NUMBER:'Account Number'
};

export const SUBMIT_CONSTANT=
{

};

export const FOOTER_CONSTANT=
{
    FOOTER_TEXT: '2003 Fifth Third Bank  |  For Authorized Internal Use Only'
};

export const URL_CONSTANT=
{
    SUBMIT_URL:'/LoanApp/LoanApplication/Submit',
    WORKBENCH_URL :'http://sdgramihqccwb04/Workbench/Workbench/Home'
};

export const CONFIRMATION_PAGE_CONSTANT={
    APP_SUBMITTED:'Application Submitted',
    APPLICATION_ID:'Application ID : ',
    BORROWER_NAME:'Borrower Name : ',
    PRODUCT_REQUESTS:'Product Requests : ',
    NEXT_STEP: 'Next Steps',
    CHECK_STATUS:'Check the status of this application in',
    CHECK_DECISION:'Check the Decision Summary',
};
export const POSITION=
{
    BOTTOM:'bottom',
    TOP:'top',
    LEFT:'left',
    RIGHT:'right',
    HORIZONTAL:'horizontal',
    VERTICAL:'vertical'
};

export const LEGEND_CONSTANT={
    REQUIRED_FIELD:'* Required Field(s)'
}