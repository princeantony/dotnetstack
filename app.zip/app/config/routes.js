import React from 'react'
import { Route, IndexRoute } from 'react-router'
import App from '../containers/App'
import Borrower from '../components/Borrower'
import ProductRequest from '../components/ProductRequest'

export default (
  <Route path="/LoanApp/LoanApplication/Load" component={App}>
      <Route path="/LoanApp/LoanApplication/productRequest" component={ProductRequest} />
           <IndexRoute component={Borrower} />
  </Route>
)
