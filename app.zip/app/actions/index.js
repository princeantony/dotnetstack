import * as actionType from '../constants/ActionTypes';

let getAppSummaryInfo = (stateObj) => {
    if(stateObj.SecurityRole=="Retail Manager"){
        let {SecurityRole,EmployeeName,EmployeeNumber,Affiliate,CostCenterNumber,FinancialCenter,FcNumber,ApplicationID,ReferredByEmployeeID,RecipientEmailCommunication}=stateObj;
        return {SecurityRole,EmployeeName,EmployeeNumber,Affiliate,CostCenterNumber,FinancialCenter,FcNumber,ApplicationID,ReferredByEmployeeID,RecipientEmailCommunication};
    }
    else
    {
        let {SecurityRole,EmployeeName,EmployeeNumber,Affiliate,FinancialCenter,ApplicationID,ReferredByEmployeeID,RecipientEmailCommunication,OfficerFullName,BbPbOfficerNumber}=stateObj;
        return {SecurityRole,EmployeeName,EmployeeNumber,Affiliate,FinancialCenter,ApplicationID,ReferredByEmployeeID,RecipientEmailCommunication,OfficerFullName,BbPbOfficerNumber};
    }
}

let getBorrowerInfo = (stateObj) => {
    let Borrower = stateObj.Borrower;
    return Borrower;
}


let getProductRequestInfo = (stateObj) => {
    let productRequest=((stateObj.Products!=null)?(stateObj.Products[0]):(null));
    return  productRequest;
}

let getLeftNavInfo = (stateObj) => {
    let ProductID = ((stateObj.Products[0].ProductID != null && stateObj.Products[0].ProductID != "")?(stateObj.Products[0]):(1));
    return ProductID;
}


export function Get(type, stateObj)
{
    switch (type)
    {
        case actionType.GET_APP_SUMMARY_INFORMATION:
            {
                return getAppSummaryInfo(stateObj);
            }
        case actionType.GET_BORROWER_INFORMATION:
            {
                return getBorrowerInfo(stateObj);
            }
        case actionType.GET_PRODUCTREQUEST_INFORMATION:
            {
                return getProductRequestInfo(stateObj);
            }
        case actionType.GET_PRODUCT_ID_INFORMATION:
            {
                return getLeftNavInfo(stateObj);
            }

        default: return null;
    }
}
