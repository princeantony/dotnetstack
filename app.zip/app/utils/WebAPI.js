﻿import {URL_CONSTANT} from '../constants/ApplicationConstants'

var WebApi =
{
    submitLoanApplition: function(data){
        var confirmationDetails=null;
        $.ajax(
          {
              async:false,
              type: 'POST',
              url: URL_CONSTANT.SUBMIT_URL,
              data: { 'data': JSON.stringify(data) },
              success: function(result) {
                  confirmationDetails=result;
              },
              error:function(){
                  confirmationDetails=null;
              }
          });
        return  confirmationDetails;
    }
};

module.exports = WebApi;
