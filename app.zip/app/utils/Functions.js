﻿import React from 'react'


let validateArrayData = (items) => {
    let isValid=((items!=null && items!='')?(true):(false));
    return  isValid;
}

export{
validateArrayData
};