import React, { Component, PropTypes } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Header from '../components/Header'
import ApplicationSummary from '../components/ApplicationSummary'
import SearchPage from '../components/SearchPage'
import LeftNavigation from '../components/LeftNavigation'
import SubmitSection from '../components/SubmitSection'
import Footer from '../components/Footer'
import FormField from '../components/form-components/FormField'
import * as actionType from '../constants/ActionTypes'
import  {Get} from '../actions'



class App extends Component {
    constructor(props){
        super(props);
        this.state = {
            completed: 0,
            delay:10,
        };
    }

    componentDidMount() {
        setTimeout(() => this.progress(5), this.state.delay);
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    progress(completed) {
        if (completed > 100) {
            this.setState({completed: 100});
        } else {
            this.setState({completed});
            const diff = Math.random() * 10;
            setTimeout(() => this.progress(completed + diff), this.state.delay);
        }
    }

    render() {
        const {  applicationsummary, borrowerinformation,leftnavigationinformation,productrequestinformation, loanapplication } = this.props
        return (
                <div>
                  <Header/>
                   <div  className="mar-t-m-3px col-lg-12 pad-l-0px pad-r-0px">
                            <FormField type="linear-progress" ref="loanAppLoader" isActive={true} cssClass="custom-progress-bar" isStriped={true} delay={this.state.delay} />
                     </div>
        {(this.state.completed>=100)?
          (<div>   
         <ApplicationSummary applicationsummary={applicationsummary} />
         {/*<div className="col-lg-12 pad-r-0px pad-l-0px mar-b-7px pad-t-25px min-height">
                <SearchPage />
          </div>*/}
                             <div className="col-lg-3 mar-t-7px pad-l-7px pad-r-7px">
                                                      <LeftNavigation  leftnavigationinformation={leftnavigationinformation} />
                                                    </div>
                                <div  className="col-lg-9 mar-t-7px pad-l-7px pad-r-7px">
                                {React.cloneElement(this.props.children, {
                                    borrowerinformation: this.props.borrowerinformation,
                                    productrequestinformation: this.props.productrequestinformation
                                })}
                                    <SubmitSection loanapplication={loanapplication} />
                              </div>
                          </div>):(<div className="col-lg-12 pad-r-0px pad-l-0px min-height">"Loading...."</div>)}
                  <Footer />
                </div>
              )
            }
            }

            let mapStateToProps = (state) => {
                return {
                    loanapplication:state.loanapplication,
                    applicationsummary: Get(actionType.GET_APP_SUMMARY_INFORMATION,state.loanapplication),
                    borrowerinformation: Get(actionType.GET_BORROWER_INFORMATION,state.loanapplication),
                    leftnavigationinformation:Get(actionType.GET_PRODUCT_ID_INFORMATION,state.loanapplication),
                    productrequestinformation:Get(actionType.GET_PRODUCTREQUEST_INFORMATION,state.loanapplication)
                }
            }

                /*function mapDispatchToProps(dispatch) {
                    return {
                        actions: bindActionCreators(TodoActions, dispatch)
                    }
                }*/

export default connect(
    mapStateToProps
)(App)