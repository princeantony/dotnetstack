import { combineReducers } from 'redux'
import { routerReducer as routing } from 'react-router-redux'
import loanapplication from './loanapplication'

const rootReducer = combineReducers({
    loanapplication,
    routing
})
export default rootReducer
