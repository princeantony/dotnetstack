var path = require('path')
var webpack = require('webpack')
var ExtractTextPlugin = require('extract-text-webpack-plugin')
///var CommonsPlugin = new require("webpack/lib/optimize/CommonsChunkPlugin")
module.exports = {
    devtool: 'cheap-module-eval-source-map',
    eslint: {
        configFile: '.eslintrc'
    },
    ///Entry point for LoanApplication
    entry: [
      './app/index'
    ],
    ///The generated files will reside in the below path
    output: {
        path: path.join(__dirname, 'public'),
        filename: 'bundle.js',
        publicPath: '/LoanApp/public/'
    },
    ///Modules required to generate the compiled code
    module: {
        preLoaders: [
          {
              test: /\.js$/,
              loader: "eslint-loader?{rules:{semi:0}}",
              exclude: /node_modules/,
          },
        ],
        loaders: [
          //Extract fonts during build
          { test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/, loader: "url-loader?limit=10000&mimetype=application/font-woff" },
          //Extract images during build
          { test: /\.(ttf|eot|svg|png)(\?v=[0-9]\.[0-9]\.[0-9])?$/, loader: "file-loader" },
          //Extract javascript files during build
          { test: /\.js$/, loaders: ['babel'], exclude: /node_modules/, include: __dirname },
          // Extract CSS during build
          {
              test: /\.css?$/, loaders: ['style', 'raw'], include: __dirname
          },
          //Extract {less} during build
          {
              test: /\.less$/, loader: ExtractTextPlugin.extract("style-loader", "css-loader!less-loader")
          }
        ]
    },
    ///For more information check https://github.com/webpack/docs/wiki/optimization for optimization
    plugins: [
        new webpack.DefinePlugin({
            "process.env": {
                NODE_ENV: JSON.stringify("production")
            }
        }),
        /* new CommonsPlugin({
             minChunks: 3,
             name: "entry"
         }),*/
      /*While writing your code, you may have already added many code split points to load stuff on demand.
      After compiling you might notice that there are too many chunks that are too small - creating larger HTTP overhead.
      Luckily, Webpack can post-process your chunks by merging them.*/
      new webpack.optimize.LimitChunkCountPlugin({ maxChunks: 15 }),
      new webpack.optimize.MinChunkSizePlugin({ minChunkSize: 10000 }),
      new webpack.optimize.OccurrenceOrderPlugin(),
      /*For finding duplication of files and folders and make them one copy, so bundle will not have duplicate files*/
      new webpack.optimize.DedupePlugin(),
      /*Enables Hot Module Replacement. (This requires records data if not in dev-server mode, recordsPath)
      For more information https://webpack.github.io/docs/list-of-plugins.html#hotmodulereplacementplugin
      */
      new webpack.HotModuleReplacementPlugin(),
      ///new webpack.optimize.AggressiveMergingPlugin(),
      /*For minification of output/generated files*/
      new webpack.optimize.UglifyJsPlugin({
          compress: {
              pure_getters: true,
              unsafe: true,
              unsafe_comps: true,
              screw_ie8: true,
              warnings: false
          }
      }),
      // Output extracted CSS to a file
      new ExtractTextPlugin('../public/assets/styles/styles.css'),
    ]
}